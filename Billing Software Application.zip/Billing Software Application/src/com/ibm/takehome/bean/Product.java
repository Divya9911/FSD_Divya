package com.ibm.takehome.bean;

import com.ibm.takehome.service.ProductService;

public class Product {
Integer productid;
String productname;
String productcategory;
int productprice;
public Product() {
	
}

public Product(Integer productid, String productname, String productcategory,int productprice) {
	super();
	this.productid = productid;
	this.productname = productname;
	this.productcategory = productcategory;
	this.productprice = productprice;
}
ProductService service = new ProductService(); 
public int getProductid() {
	return productid;
}
public void setProductid(Integer productid) {
	this.productid = productid;
}
public String getProductname() {
	return productname;
}
public void setProductname(String productname) {
	this.productname = productname;
}
public String getProductcategory() {
	return productcategory;
}
public void setProductcategory(String productcategory) {
	this.productcategory = productcategory;
}
public int getProductprice() {
	return productprice;
}
public void setProductprice(int productprice) {
	this.productprice = productprice;
}
public String toString() {
	return "productname=" + productname + ","+ "productcategory= " + productcategory +" ,"
					+ "productprice = "+productprice+","; 
}
}
