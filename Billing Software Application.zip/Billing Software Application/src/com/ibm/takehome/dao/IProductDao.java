package com.ibm.takehome.dao;

public interface IProductDao {

}
