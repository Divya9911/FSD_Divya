package com.ibm.takehome.dao;

import java.util.HashMap;
import java.util.Map;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.util.CollectionUtil;

public class ProductDao implements IProductDao {
	
	
	
	Map<Integer,Object> products =new HashMap<>();
	
	public void storeIntoMap(Product product1, Product product2, Product product3, Product product4) {
	
	 products.put(1001,product1);
	 products.put(1002,product2);
	 products.put(1003,product3);
	 products.put(1004,product4);
	}
	
	
	public Map<Integer, Object> calculateTotal() {
		
		return products;
	}


	public Map<Integer, Object> showDetails() {
		// TODO Auto-generated method stub
		return products;
	}


	
	
	
}
