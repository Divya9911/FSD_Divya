package com.ibm.takehome.service;

import com.ibm.takehome.bean.Product;

public interface IProductService {

	

	boolean validateQuantity(int productquantity);

	void storeIntoMap(Product product1, Product product2, Product product3, Product product4);

	String showDetails();

	boolean validateProductId(Integer productid);
	

	int calculateTotal(Integer productid, int productquantity);

	

	

}
