package com.ibm.takehome.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.dao.ProductDao;


public class ProductService implements IProductService {
	ProductDao dao =new ProductDao(); 
	Product p;
	public int linetotal;
	String str="";
	@Override
	public boolean validateProductId(Integer productid) {
		return true;
		
	}

	@Override
	public boolean validateQuantity(int productquantity) {
		if(productquantity<=0) 
		{
			return false;
		}
			else
			return true;
		}
		
	

	
	@Override
	public int calculateTotal(Integer productid, int productquantity) {
		Map<Integer,Object> map =  (HashMap) dao.calculateTotal();
		for(Map.Entry m :map.entrySet()) {
			if(m.getKey().equals(productid)) {
			p=(Product)m.getValue();
			int price =p.getProductprice();
			linetotal = price * productquantity;
			//System.out.println(linetotal);
			
		}}
		return linetotal;
	
		
	}

	@Override
	public void storeIntoMap(Product product1, Product product2, Product product3, Product product4) {
		dao.storeIntoMap(product1, product2, product3, product4);
		
	}

	@Override
	public String showDetails() {
		Map<Integer,Object> map =  (HashMap) dao.showDetails();
		for(Map.Entry m :map.entrySet()) {
			str = str +"Id : "+m.getKey()+ ": "+m.getValue();
			
		}
		return str;
		
	}

	

	//@Override
	/*public String Bill(Integer productid, int productquantity) {
		Map<Integer,Object> map =  (HashMap) dao.calculateTotal();
		for(Map.Entry m :map.entrySet()) {
			System.out.println(m.getKey().equals(productid));
			if(m.getKey().equals(productid)) {
			p=(Product)m.getValue();
			int price =p.getProductprice();
			linetotal = price * productquantity;
			//System.out.println(linetotal);
			str = str +"Id : "+m.getKey()+ ": "+m.getValue()+": "+linetotal;
			}
		}
	
		return str;
			
	}*/

	

}
