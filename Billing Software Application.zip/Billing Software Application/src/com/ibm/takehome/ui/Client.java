package com.ibm.takehome.ui;

import java.util.Scanner;

import com.ibm.takehome.bean.Product;
import com.ibm.takehome.service.IProductService;
import com.ibm.takehome.service.ProductService;
import com.ibm.takehome.util.CollectionUtil;
class Client {

	public static void main(String[] args) {
		IProductService service = new ProductService();
		CollectionUtil collect = new CollectionUtil();
		Product product1 =new Product(1001,"iphone","Electronics",35000);
		Product product2 =new Product(1002,"LED Tv","Electronics",45000);
		Product product3 =new Product(1003,"Telescope","Toy",8000);
		Product product4 =new Product(1004,"Teddy","Toy",500);
		service.storeIntoMap(product1,product2,product3,product4);
		Integer productid;
		int productquantity;
		System.out.println("Enter your choice. \n 1.Generate Bill by entering product code and quantity \n 2. Exit");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		sc.nextLine();
		switch(choice) {
		
		case 1: while(true) {
				System.out.println("Enter product id");
				productid = sc.nextInt();
				if(!(service.validateProductId(productid))){
					System.out.println("Entered name is wrong");
				}
				break;
				}
			    while(true) {
				System.out.println("Enter product quantity");
				productquantity =sc.nextInt();
				if(!(service.validateQuantity(productquantity))) {
					System.out.println("Entered quantity is less than 0");
				}
				break;
			    }
				System.out.println(service.showDetails());
				System.out.println("Line Total is:"+service.calculateTotal(productid,productquantity));
				//System.out.println("Bill generation :"+ service.Bill(productid,productquantity));
				
				break;
		
		case 2: 
				System.out.println("Thank you!!");
				System.exit(0);
				break;
		default :System.out.println("Entered a wrong choice");
		}

}
}