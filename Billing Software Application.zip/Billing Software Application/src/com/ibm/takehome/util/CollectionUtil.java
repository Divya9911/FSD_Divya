package com.ibm.takehome.util;

import java.util.HashMap;
import java.util.Map;

import com.ibm.takehome.bean.Product;

public class CollectionUtil {
	
}
