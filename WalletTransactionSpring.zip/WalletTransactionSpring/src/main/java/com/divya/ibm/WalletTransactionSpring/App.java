package com.divya.ibm.WalletTransactionSpring;

import java.util.Map;
import java.util.Scanner;
import java.util.Map.Entry;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.divya.ibm.bean.CustomerDetails;
import com.divya.ibm.dao.CustomerDaoImpl;
import com.ibm.bean.service.CustomerServiceImpl;


public class App 
{
    public static void main( String[] args )
    {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        //CustomerDetails cust1 = context.getBean("custDetails",CustomerDetails.class);
        
        CustomerServiceImpl service = context.getBean("serviceImpl",CustomerServiceImpl.class);
        //cust.details();
        //dao.showDetails();
        int amount;
        int balance =0;
        Integer accountno=0;
		Scanner sc= new Scanner(System.in); 
		while(true) {
		System.out.println("Enter your choice 1. New User \n 2. Existing User");
		int ch=sc.nextInt();
		sc.nextLine();
		
		switch(ch) {
		
		case 1: 
				System.out.println("Enter your name");
				String name =sc.nextLine();
				System.out.println("Enter your password");
				
				String password =sc.nextLine();
				System.out.println("Enter your mobileNo");
				String mobileno =sc.nextLine();
				accountno= service.addNewUser(name,password,mobileno);
				System.out.println("Your account no is : "+accountno);
				break;
		case 2:	System.out.println("Enter your Account No"); 
				accountno = sc.nextInt();
				while(true) {
					
				System.out.println("Enter your choice: 1. Check your details \n 2. Checking balance \n 3. Deposit Money  \n 4.Withdraw Money");
				int choice = sc.nextInt();
				switch(choice) {
				
				case 1 :
						Map<Integer,Object> customer1 = service.showDetails(accountno);
						for (Entry<Integer, Object> entry : customer1.entrySet()) {
							Integer ac =((CustomerDetails) entry.getValue()).getAccountno();
							
							if(ac.equals(accountno)) 
							{
							
				            System.out.println("Name : "+((CustomerDetails) entry.getValue()).getName()); 
				            System.out.println("Accountno : "+((CustomerDetails) entry.getValue()).getAccountno()); 
				            System.out.println("Mobileno : "+((CustomerDetails) entry.getValue()).getMobileno()); 
				            System.out.println("Password : "+((CustomerDetails) entry.getValue()).getPassword()); 
				            System.out.println("Balance : "+((CustomerDetails) entry.getValue()).getBalance()); 
							}
						}
						break;
				case 2 :balance = service.showBalance(accountno);
						System.out.println("Your account balance is: "+balance);
						break;
				case 3 :System.out.println("Enter amount you want to deposit");
						amount = sc.nextInt();
						balance = service.depositMoney(accountno,amount);
						System.out.println("Your updated account balance is: "+balance);
						break;
				case 4 :System.out.println("Enter amount you want to withdraw");
						amount = sc.nextInt();
						balance = service.withdrawMoney(accountno,amount);
						System.out.println("Your updated account balance is: "+balance);
						break;
				default: System.out.println("Entered a wrong choice");
				}
		}}
		
		}
		
		
		
		
		 
    }
}
