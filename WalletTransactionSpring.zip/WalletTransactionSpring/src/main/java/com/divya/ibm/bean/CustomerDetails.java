package com.divya.ibm.bean;

import java.util.Map;

public class CustomerDetails {
	String name;
	String mobileno;
	String password;
	int balance;
	Integer accountno;
	public CustomerDetails(String name, String mobileno, String password,int balance,Integer accountno) {
		
		this.name = name;
		this.mobileno = mobileno;
		this.password = password;
		this.balance = balance; 
		this.accountno =accountno;
	}
	

	public CustomerDetails() {
	
	}

public String getName() {
	return name;
}

public Integer getAccountno() {
	return accountno;
}

public void setAccountno(Integer accountno) {
	this.accountno = accountno;
}

public void setName(String name) {
	this.name = name;
}

public String getMobileno() {
	return mobileno;
}

public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}


public void details() { 
	System.out.println("Name is: "+getName()+" "+"Mobile no: "+getMobileno()+ " "+"password :" +getPassword()); 
	}

public int getBalance() {
	return balance;
}



public void setBalance(int balance) {
	this.balance = balance;
}

public String toString(){
	return " " +name+ " "+mobileno+ " "+password+" "+balance ;
}

}
	
