package com.divya.ibm.dao;

import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Qualifier;

import com.divya.ibm.bean.CustomerDetails;

public class CustomerDaoImpl {
	Map<Integer,Object> customer;
	CustomerDetails cust1;
	public Map<Integer, Object> getCustomer() {
		return customer;
	}

	public void setCustomer(Map<Integer, Object> customer) {
		this.customer = customer;
	}
	
	public Map<Integer,Object> showDetails(Integer accountno){
		
		return customer;
	}

	public int showBalance(Integer accountno) {
		int balance=0;
		for (Entry<Integer, Object> entry : customer.entrySet()) {
			Integer ac =((CustomerDetails) entry.getValue()).getAccountno();
			if(ac.equals(accountno)) 
			{
				balance= ((CustomerDetails) entry.getValue()).getBalance();
			}
		
		
	} 
		return balance;
	
}

	public int depositMoney(Integer accountno, int amount) {
		int balance=0;
		int newBalance = 0;
		for (Entry<Integer, Object> entry : customer.entrySet()) {
			Integer ac =((CustomerDetails) entry.getValue()).getAccountno();
			if(ac.equals(accountno)) {
				 balance = amount + ((CustomerDetails) entry.getValue()).getBalance();
				 ((CustomerDetails)entry.getValue()).setBalance(balance);
				 newBalance =((CustomerDetails) entry.getValue()).getBalance();
			}
				
			}
		
		return newBalance;
		
	}
	

	

	public int withdrawMoney(Integer accountno, int amount) {
		int balance=0;
		int newBalance =0;
		for (Entry<Integer, Object> entry : customer.entrySet()) {
			Integer ac =((CustomerDetails) entry.getValue()).getAccountno();
			if(ac.equals(accountno)) {
				 balance =((CustomerDetails) entry.getValue()).getBalance()-amount;
				 ((CustomerDetails)entry.getValue()).setBalance(balance);
				 newBalance =((CustomerDetails) entry.getValue()).getBalance();
				 
			}
				
		}
		return newBalance;
		
	}

	public Integer addNewUser(int id, CustomerDetails cd) {
		Integer accountno=0;
		customer.put(id, cd);
		for (Entry<Integer, Object> entry : customer.entrySet()) {
			if(entry.getKey().equals(id)) {
             
             accountno = ((CustomerDetails) entry.getValue()).getAccountno(); 
            }
		}
		return accountno;
		
	}
	}
