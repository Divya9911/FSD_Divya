package com.divya.ibm.dao;

public interface UserDao {

}
