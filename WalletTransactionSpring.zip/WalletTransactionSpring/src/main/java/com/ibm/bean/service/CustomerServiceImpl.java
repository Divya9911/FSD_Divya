package com.ibm.bean.service;

import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;

import com.divya.ibm.bean.CustomerDetails;
import com.divya.ibm.dao.CustomerDaoImpl;

public class CustomerServiceImpl {
	CustomerDaoImpl dao;
	
	public CustomerDaoImpl getDao() {
		return dao;
	}
	public void setDao(CustomerDaoImpl dao) {
		this.dao = dao;
	}
	public Map<Integer, Object> showDetails(Integer accountno) {
		Map<Integer,Object> customer = dao.showDetails(accountno);
		return customer;
	}
	public int showBalance(Integer accountno) {
		int balance = dao.showBalance(accountno);
		return balance;
	}
	public int depositMoney(Integer accountno, int amount) {
		int balance = dao.depositMoney(accountno,amount);
		return balance;
	}
	public Integer addNewUser(String name, String password, String mobileno) {
	
		Integer accountno = (int) ((Math.random()*1000)+1);
		int balance =1000;
		CustomerDetails cd= new CustomerDetails(name,mobileno,password,balance,accountno);
		Integer id =3;
		Integer accountno1 = dao.addNewUser(id,cd);
		id++;
		return accountno1;
		
		
	}
	public int withdrawMoney(Integer accountno, int amount) {
		int balance =dao.withdrawMoney(accountno,amount);
		return balance;
		
	}

}
