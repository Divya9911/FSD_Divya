package com.ibm.bean.service;

public interface UserService {

}
