package com.ibm.training.employee;

public class Employee {
	String Ename;
	Integer EmpId;
	Integer Salary;
	String Designation;
	Employee(){
		
	}
	public Employee(String ename, Integer empId, Integer salary, String designation) {
		super();
		Ename = ename;
		EmpId = empId;
		Salary = salary;
		Designation = designation;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public Integer getEmpId() {
		return EmpId;
	}
	public void setEmpId(Integer empId) {
		EmpId = empId;
	}
	public Integer getSalary() {
		return Salary;
	}
	public void setSalary(Integer salary) {
		Salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
}
