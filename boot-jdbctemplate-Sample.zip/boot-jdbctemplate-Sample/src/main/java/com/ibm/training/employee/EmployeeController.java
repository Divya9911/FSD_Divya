package com.ibm.training.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	EmployeeService service;
	
	// Details of all the employees
	@RequestMapping("/emp")
	List<Employee> getEmployees() {
		return service.getEmployees();
		
	}
	
	//Details of particular employee
	@RequestMapping("/emp/{id}")
		List<Employee> getEmployee(@PathVariable Integer id){
			return service.getEmployee(id);
		}
	
	//Add new Employee
	@RequestMapping(method = RequestMethod.POST,value = "/emp")
	void addEmployee(@RequestBody Employee emp) {
		service.addEmployee(emp);
	}
 	
	//Update employee details
	@RequestMapping(method = RequestMethod.PUT,value="/emp/{id}")
	void updateEmployee(@RequestBody Employee emp, @PathVariable Integer id) {
		service.updateEmployee(emp,id);
	}
	
	//Delete employee details
	@RequestMapping(method = RequestMethod.DELETE,value="/emp/{id}")
	void deleteEmployee(@PathVariable Integer id) {
		service.deleteEmployee(id);
	}
	
	
	
	
	
}
