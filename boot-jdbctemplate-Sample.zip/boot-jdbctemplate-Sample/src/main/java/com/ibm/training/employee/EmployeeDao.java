package com.ibm.training.employee;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
@Repository
public class EmployeeDao {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	

	public List<Employee> getEmployees() {
		String sql ="select * from employee_new"; 
		return  jdbcTemplate.query(sql,new EmployeeMapper());
	}
	
	public List<Employee> getEmployee(Integer id){
		String sql ="select * from employee_new where EmpId=?";
		return jdbcTemplate.query(sql, new Object[] {id},new EmployeeMapper());
	}
	
	public void addEmployee(Employee emp) {
		String sql ="insert into employee_new values(:ename,:eid,:esal,:edes)";
		SqlParameterSource paramSource =new MapSqlParameterSource("ename",emp.getEname())
				.addValue("eid",emp.getEmpId())
				.addValue("esal",emp.getSalary()) 
				.addValue("edes",emp.getDesignation());
		namedParameterJdbcTemplate.update(sql, paramSource);
			
	}

	public void updateEmployee(Employee emp, Integer id) {
		String sql="update employee_new set Ename=:ename where EmpId=:eid";	
		SqlParameterSource paramSource =new MapSqlParameterSource("ename",emp.getEname())
				.addValue("eid", id);
		namedParameterJdbcTemplate.update(sql, paramSource);
	}
	
	public void deleteEmployee(Integer id) {
		String sql="delete from employee_new where EmpId=:eid";
		SqlParameterSource paramSource =new MapSqlParameterSource("eid",id);
		namedParameterJdbcTemplate.update(sql, paramSource);
	}
		
	

	class EmployeeMapper implements RowMapper<Employee>{

		public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
			Employee emp =new Employee();
			emp.setEname(rs.getString("Ename"));
			emp.setEmpId(rs.getInt("EmpId"));
			emp.setSalary(rs.getInt("Salary"));
			emp.setDesignation(rs.getString("Designation"));
			
			return emp;
		}
		
	}



	

}

