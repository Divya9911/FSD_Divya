package com.ibm.training.employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao dao;
	
	public List<Employee> getEmployees() {
		
		return dao.getEmployees();
	}

	public List<Employee> getEmployee(Integer id) {
		// TODO Auto-generated method stub
		return dao.getEmployee(id);
	}

	public void addEmployee(Employee emp) {
		dao.addEmployee(emp);
		
	}

	public void updateEmployee(Employee emp, Integer id) {
		dao.updateEmployee(emp,id);
		
	}

	public void deleteEmployee(Integer id) {
		dao.deleteEmployee(id);
		
	}

}
